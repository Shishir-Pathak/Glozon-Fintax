import Career from "../model/careerModel.js";

// =====================================================
// SUBMIT CAREER FORM
// =====================================================

export async function submitCareerForm(req, res) {
  try {
    console.log("========================================");
    console.log("CAREER FORM SUBMISSION");
    console.log("========================================");

    console.log("BODY:", req.body);
    console.log("FILE:", req.file);

    const {
      fullName,
      email,
      phoneNumber,
      country,
      position,
      experience,
      linkedInUrl,
      coverLetter,
    } = req.body || {};

    // ===================================================
    // CHECK REQUIRED FIELDS
    // ===================================================

    if (
      !fullName ||
      !email ||
      !phoneNumber ||
      !country ||
      !position ||
      !experience ||
      !coverLetter
    ) {
      return res.status(400).json({
        message: "All required fields must be filled.",
      });
    }

    // ===================================================
    // CHECK CV
    // ===================================================

    if (!req.file) {
      return res.status(400).json({
        message: "Please upload your CV.",
      });
    }

    // ===================================================
    // GET CLOUDINARY CV URL
    // ===================================================

    const resumeUrl =
      req.file.path ||
      req.file.secure_url ||
      req.file.url ||
      null;

    if (!resumeUrl) {
      return res.status(500).json({
        message: "CV uploaded but URL could not be obtained.",
      });
    }

    console.log("CV URL:", resumeUrl);

    // ===================================================
    // CREATE CAREER APPLICATION
    // ===================================================

    const newCareerForm = await Career.create({
      fullName,
      email,
      phoneNumber,
      country,
      position,
      experience,
      linkedInUrl: linkedInUrl || null,
      coverLetter: coverLetter || null,
      resumeUrl,
      approveStatus: "pending",
    });

    // ===================================================
    // SUCCESS
    // ===================================================

    return res.status(201).json({
      message: "Career form submitted successfully",
      careerFormId: newCareerForm.id,
      resumeUrl: newCareerForm.resumeUrl,
    });
  } catch (error) {
    console.error("========================================");
    console.error("CAREER FORM SUBMISSION ERROR");
    console.error("========================================");
    console.error(error);

    return res.status(500).json({
      message: "Internal server error",
      error: error.message,
    });
  }
}

// =====================================================
// GET ALL CAREERS
// =====================================================

export async function getCareers(req, res) {
  try {
    const careers = await Career.findAll({
      order: [["createdAt", "DESC"]],
    });

    return res.status(200).json(careers);
  } catch (error) {
    console.error("GET CAREERS ERROR:", error);

    return res.status(500).json({
      message: "Internal server error",
      error: error.message,
    });
  }
}

// =====================================================
// DELETE CAREER
// =====================================================

export async function deleteCareer(req, res) {
  try {
    const { id } = req.params;

    const deletedCareer = await Career.destroy({
      where: {
        id,
      },
    });

    if (!deletedCareer) {
      return res.status(404).json({
        message: "Career application not found",
      });
    }

    return res.status(200).json({
      message: "Career deleted successfully",
    });
  } catch (error) {
    console.error("DELETE CAREER ERROR:", error);

    return res.status(500).json({
      message: "Internal server error",
      error: error.message,
    });
  }
}

// =====================================================
// UPDATE CAREER STATUS
// =====================================================

export async function updateCareer(req, res) {
  try {
    const { id } = req.params;
    const { status } = req.body || {};

    if (!status) {
      return res.status(400).json({
        message: "Status is required",
      });
    }

    const allowedStatuses = [
      "pending",
      "shortlisted",
      "approved",
      "rejected",
    ];

    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({
        message: "Invalid status",
      });
    }

    const [updatedRows] = await Career.update(
      {
        approveStatus: status,
      },
      {
        where: {
          id,
        },
      }
    );

    if (updatedRows === 0) {
      return res.status(404).json({
        message: "Career application not found",
      });
    }

    return res.status(200).json({
      message: "Career status changed successfully",
    });
  } catch (error) {
    console.error("UPDATE CAREER ERROR:", error);

    return res.status(500).json({
      message: "Internal server error",
      error: error.message,
    });
  }
}