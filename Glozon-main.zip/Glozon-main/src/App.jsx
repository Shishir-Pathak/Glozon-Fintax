import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";

import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Services from "./components/Services";
import WhyChooseUs from "./components/WhyChooseUs";
import MissionStatement from "./components/MissionStatement";
import Testimonials from "./components/Testimonials";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

import Login from "./pages/auth/Login";
import Dashboard from "./pages/admin/Dashboard";

import ClientOnboardingForm from "./components/ClientOnboardingForm";
import CareerForm from "./components/CareerForm";

import ServicesPage from "./pages/admin/ServicesPage";
import InquiriesPage from "./pages/admin/InquiriesPage";
import TeamPage from "./pages/admin/TeamPage";
import ClientOnBoardingPage from "./pages/admin/ClientOnBoardingPage";
import CareersPage from "./pages/admin/CareersPage";
import TestimonialsPage from "./pages/admin/TestimonialsPage";
import SettingsPage from "./pages/admin/SettingsPage";

import AdminLayout from "./layouts/AdminLayout";
import NotFound from "./components/NotFound";

// Home page
function HomePage() {
  const location = useLocation();

  useEffect(() => {
    if (location.state?.scrollTo === "about") {
      const el = document.getElementById("about");

      if (el) {
        el.scrollIntoView({ behavior: "smooth" });
      }
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [location]);

  return (
    <div id="top">
      <Hero />
      <About />
      <Services />
      <WhyChooseUs />
      <MissionStatement />
      <Testimonials />
    </div>
  );
}

// App content with location access
function AppContent() {
  const location = useLocation();

  // Hide public navbar and footer on admin and login pages
  const hidePublicLayout =
    location.pathname.startsWith("/admin") || location.pathname === "/login";
  let role = null;
  try {
    role = JSON.parse(atob(localStorage.getItem("token")?.split(".")[1]));
  } catch {
    role = undefined;
  }

  return (
    <>
      {!hidePublicLayout && <Navbar />}

      <Routes>
        {/* Home */}
        <Route path="/" element={<HomePage />} />

        {/* Client onboarding */}
        <Route path="/client-onboarding" element={<ClientOnboardingForm />} />
        <Route
          path="/client-onboarding/individual"
          element={<ClientOnboardingForm />}
        />
        <Route
          path="/client-onboarding/company"
          element={<ClientOnboardingForm />}
        />

        {/* Public Career Form */}
        <Route path="/career" element={<CareerForm />} />

        {/* Contact */}
        <Route path="/contact-us" element={<Contact />} />

        {/* Login */}
        <Route path="/login" element={<Login />} />

        {/* Admin Layout + Nested Pages */}
        <Route
          path="/admin"
          element={
            role && role.role == "admin" ? <AdminLayout /> : <NotFound />
          }
        >
          {/* Dashboard */}
          <Route index element={<Dashboard />} />

          {/* Services */}
          <Route path="services" element={<ServicesPage />} />

          {/* Inquiries */}
          <Route path="inquiries" element={<InquiriesPage />} />

          {/* Team */}
          <Route path="team" element={<TeamPage />} />

          {/* Client Onboarding */}
          <Route path="client-onboarding" element={<ClientOnBoardingPage />} />

          {/* Careers */}
          <Route path="careers" element={<CareersPage />} />

          {/* Testimonials */}
          <Route path="testimonials" element={<TestimonialsPage />} />

          <Route path="settings" element={<SettingsPage />} />
        </Route>
      </Routes>

      {!hidePublicLayout && <Footer />}
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}
