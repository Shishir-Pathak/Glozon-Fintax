import { useState } from "react";
import { motion } from "framer-motion";
import API from "../API/Api.js";
export default function CareerForm() {
  const [sending, setSending] = useState(false);
  const [cvName, setCvName] = useState("");
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phoneNumber: "",
    country: "",
    position: "",
    experience: "",
    linkdinUrl: "",
    coverLetter: "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setSending(true);

    // Frontend demo only
    try {
      const res = await API.post("/careers", formData);
      e.target.reset();
      setFormData({});
      alert("Application Submitted Successfully");
    } catch (e) {
      console.error(e);
    }

    alert("Application submitted successfully!");

    setCvName("");
    setSending(false);
  };

  return (
    <div className="bg-gray-50 py-16 md:py-20 mb-16">
      {/* Careers heading outside the form box */}
      <div className="max-w-3xl mx-auto text-center px-4 mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4">
          Careers
        </h1>

        <p className="text-gray-600 leading-relaxed text-lg">
          We welcome applications from professionals who share our commitment to
          quality offshore financial and taxation services. Complete the form
          below and attach your CV — our team will review your application by
          email.
        </p>
      </div>

      {/* Form box */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl mx-auto bg-white p-6 md:p-8 rounded-xl shadow-lg border border-gray-200"
      >
        <h2 className="text-2xl font-bold text-blue-900 mb-2">Apply Now</h2>

        <p className="text-gray-600 mb-6">
          Fill the form below and upload your CV.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name */}
          <div>
            <label className="block text-sm font-medium mb-1">
              Full Name *
            </label>
            <input
              type="text"
              required
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              name="fullName"
              onChange={handleChange}
            />
          </div>

          {/* Email + Mobile */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Email *</label>
              <input
                type="email"
                name="email"
                onChange={handleChange}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Mobile *</label>
              <input
                type="tel"
                required
                placeholder="+977 9845971220"
                name="phoneNumber"
                onChange={handleChange}
                className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Country */}
          <div>
            <label className="block text-sm font-medium mb-1">Country *</label>
            <select
              required
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              name="country"
              onChange={handleChange}
            >
              <option value="">Select Country</option>
              <option>Australia</option>
              <option>Nepal</option>
              <option>India</option>
              <option>Dubai</option>
            </select>
          </div>

          {/* Position */}
          <div>
            <label className="block text-sm font-medium mb-1">Position *</label>
            <select
              required
              onChange={handleChange}
              name="position"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Position</option>
              <option>Accounting & Financial Reporting</option>
              <option>Taxation & Regulatory Advisory</option>
              <option>Audit Support & Assurance</option>
              <option>Payroll Processing & Administration</option>
              <option>Strategic Advisory & Corporate Finance</option>
            </select>
          </div>

          {/* Experience */}
          <div>
            <label className="block text-sm font-medium mb-1">
              Experience *
            </label>
            <select
              required
              onChange={handleChange}
              name="experience"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Experience</option>
              <option>Fresher</option>
              <option>0-1 years</option>
              <option>1-3 years</option>
              <option>3-5 years</option>
              <option>5+ years</option>
            </select>
          </div>

          {/* LinkedIn */}
          <div>
            <label className="block text-sm font-medium mb-1">
              LinkedIn (optional)
            </label>
            <input
              type="url"
              placeholder="https://linkedin.com/in/..."
              onChange={handleChange}
              name="linkdinUrl"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Cover Letter */}
          <div>
            <label className="block text-sm font-medium mb-1">
              Cover Letter *
            </label>
            <textarea
              rows={5}
              required
              placeholder="Tell us about your skills and why you want to join GFA…"
              onChange={handleChange}
              name="coverLetter"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            ></textarea>
          </div>

          {/* CV Upload */}
          <div>
            <label className="block text-sm font-medium mb-1">
              Upload CV *
            </label>

            <input
              type="file"
              // required
              accept=".pdf,.doc,.docx"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              onChange={(e) => setCvName(e.target.files[0]?.name || "")}
            />

            {cvName && (
              <p className="text-sm text-gray-500 mt-2">Selected: {cvName}</p>
            )}
          </div>

          {/* Submit */}
          <div className="pt-4">
            <button
              type="submit"
              disabled={sending}
              className="w-full md:w-auto bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors disabled:opacity-60"
            >
              {sending ? "Submitting..." : "Submit Application"}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
