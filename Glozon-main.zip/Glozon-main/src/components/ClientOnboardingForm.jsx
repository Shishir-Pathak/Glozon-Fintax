import { useState, useRef, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import API from "../API/Api";
import { buildGfaTaxAuthorityPdfBlob } from "../utils/gfaTaxAuthorityPdf.js";

const inputClass =
  "w-full px-4 py-3 border border-gray-300 rounded-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors bg-white text-gray-800";

const labelClass = "block text-sm font-semibold text-gray-800 mb-1.5";

const sectionTitle =
  "text-lg font-bold text-blue-800 border-b-2 border-blue-600 pb-2 mb-6";

const tableInputClass =
  "w-full px-3 py-2 border border-gray-300 rounded-sm bg-white text-gray-800 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors";

function InfoRow({ label, required, striped, children }) {
  return (
    <div
      className={`grid grid-cols-1 sm:grid-cols-[200px_1fr] ${
        striped ? "bg-gray-50" : "bg-white"
      } border-b border-gray-200 last:border-b-0`}
    >
      <div className="px-4 py-3 flex items-center text-sm font-semibold text-gray-800 sm:border-r border-gray-200">
        {label}
      </div>

      <div className="px-4 py-3 flex items-center gap-2">
        <div className="flex-1 min-w-0">{children}</div>
        {required && <span className="text-red-500 font-bold shrink-0">*</span>}
      </div>
    </div>
  );
}

function SignatureField({ onSignatureChange }) {
  const canvasRef = useRef(null);
  const drawing = useRef(false);
  const lastPoint = useRef(null);

  const resetCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.width = canvas.offsetWidth || 600;
    canvas.height = 160;

    const ctx = canvas.getContext("2d");
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = "#1e3a8a";
    ctx.lineWidth = 2;

    onSignatureChange({ dataUrl: "", hasInk: false });
  }, [onSignatureChange]);

  useEffect(() => {
    resetCanvas();
  }, [resetCanvas]);

  const getPoint = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();

    const clientX = e.touches?.[0]?.clientX ?? e.clientX;
    const clientY = e.touches?.[0]?.clientY ?? e.clientY;

    return {
      x: ((clientX - rect.left) / rect.width) * canvas.width,
      y: ((clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const start = (e) => {
    e.preventDefault();
    drawing.current = true;
    lastPoint.current = getPoint(e);
  };

  const move = (e) => {
    e.preventDefault();

    if (!drawing.current || !canvasRef.current || !lastPoint.current) return;

    const ctx = canvasRef.current.getContext("2d");
    const p = getPoint(e);

    ctx.beginPath();
    ctx.moveTo(lastPoint.current.x, lastPoint.current.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();

    lastPoint.current = p;

    onSignatureChange({
      dataUrl: canvasRef.current.toDataURL("image/png"),
      hasInk: true,
    });
  };

  const end = () => {
    drawing.current = false;
    lastPoint.current = null;
  };

  return (
    <div>
      <p className={`${labelClass} mb-2`}>Signature box (mouse or touch)</p>

      <motion.div className="border-2 border-dashed border-gray-300 rounded-sm bg-gray-50 overflow-hidden">
        <canvas
          id="canvas"
          ref={canvasRef}
          className="w-full h-40 touch-none cursor-crosshair block"
          onMouseDown={start}
          onMouseMove={move}
          onMouseUp={end}
          onMouseLeave={end}
          onTouchStart={start}
          onTouchMove={move}
          onTouchEnd={end}
        />
      </motion.div>

      <button
        type="button"
        onClick={resetCanvas}
        className="mt-2 text-sm font-semibold text-blue-600 hover:text-blue-800 underline"
      >
        Clear signature
      </button>
    </div>
  );
}

const DECLARATION = [
  "I declare that the information provided above is true and correct to the best of my knowledge and belief.",
  "I authorize Glozon FinTax & Advisory Pvt. Ltd. to act on my behalf in relation to my taxation and accounting affairs.",
];

export default function ClientOnboardingForm() {
  const [businessType, setBusinessType] = useState("individual");
  const [signature, setSignature] = useState({ dataUrl: "", hasInk: false });
  const [signatureKey, setSignatureKey] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    address: "",
    country: "",
    maritalStatus: "",
    businessType: "individual",
    panId: "",
    dob: "",
    corporateId: "",
    signatureName: "",
    signatureDate: "",
    signatureUrl: "",
  });
  console.log(formData);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("hello");
    const canvas = document.getElementById("canvas");

    const form = e.currentTarget;

    if (!form.checkValidity()) {
      form.reportValidity();
      alert("Please complete all required fields.");
      return;
    }

    if (!signature.hasInk) {
      alert("Please sign in the signature box before submitting.");
      return;
    }

    setIsSubmitting(true);
    canvas.toBlob(async (b) => {
      try {
        const f = new FormData();
        f.append("signatureImg", b, "signature.png");

        const pdfBlob = await buildGfaTaxAuthorityPdfBlob(
          formData,
          canvas.toDataURL("image/png", 0.7),
        );
        const pdf = new FormData();

        pdf.append(
          "pdf",
          pdfBlob,
          parseInt(Math.random() * 10000000).toString() +
            Date.now().toString() +
            ".pdf",
        );

        const res = await API.post("/onboarding/upload", f);
        const pdfRes = await API.post("/onboarding/pdfUpload", pdf);

        await API.post("/onboarding", {
          ...formData,
          signatureUrl: res?.data?.url,
          pdfUrl: pdfRes?.data?.url,
        });
        setFormData({});
        form.reset();

        alert("Application submitted sucessfully");
        setIsSubmitting(false);
      } catch (e) {
        console.error(e);
        alert("Error occured!");
        setIsSubmitting(false);
      }
    });

    setBusinessType("individual");
    setSignature({ dataUrl: "", hasInk: false });
    setSignatureKey((k) => k + 1);
    //setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-b from-blue-900 to-blue-800 py-12 text-white md:py-16">
        <div className="container mx-auto max-w-4xl px-4 text-center">
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-2 text-sm uppercase tracking-widest text-blue-200"
          >
            Glozon FinTax & Advisory
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-3 text-3xl font-bold md:text-4xl"
          >
            Tax Authority Form
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mx-auto max-w-2xl text-lg text-blue-100"
          >
            Complete the form below.
          </motion.p>
        </div>
      </div>

      {/* Form */}
      <div className="container relative z-10 mx-auto -mt-8 max-w-3xl px-4">
        <nav className="mb-4 inline-block rounded-sm bg-white/90 px-3 py-2 text-sm text-gray-600 shadow-sm backdrop-blur">
          <Link to="/" className="hover:text-blue-600">
            Home
          </Link>
          <span className="mx-2 text-gray-400">›</span>
          <span className="font-medium text-gray-800">Client onboarding</span>
        </nav>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="overflow-hidden rounded-sm border border-gray-100 bg-white shadow-xl"
        >
          <form
            onSubmit={handleSubmit}
            className="space-y-10 px-6 py-8 md:px-10 md:py-10"
          >
            {/* Your Information */}
            <fieldset disabled={isSubmitting}>
              <h3 className={sectionTitle}>Your information</h3>

              <div className="overflow-hidden rounded-sm border border-gray-300 shadow-sm">
                <InfoRow label="First name" required>
                  <input
                    name="firstName"
                    onChange={handleChange}
                    required
                    className={tableInputClass}
                  />
                </InfoRow>

                <InfoRow label="Last name" required striped>
                  <input
                    name="lastName"
                    onChange={handleChange}
                    required
                    className={tableInputClass}
                  />
                </InfoRow>

                <InfoRow label="Email" required>
                  <input
                    type="email"
                    name="email"
                    onChange={handleChange}
                    required
                    className={tableInputClass}
                  />
                </InfoRow>

                <InfoRow label="Contact no." required striped>
                  <input
                    name="phoneNumber"
                    onChange={handleChange}
                    required
                    className={tableInputClass}
                  />
                </InfoRow>

                <InfoRow label="Residential address" required>
                  <input
                    name="address"
                    onChange={handleChange}
                    required
                    className={tableInputClass}
                  />
                </InfoRow>

                <InfoRow label="Country" required striped>
                  <input
                    name="country"
                    onChange={handleChange}
                    required
                    className={tableInputClass}
                  />
                </InfoRow>

                <InfoRow label="Marital status" required>
                  <select
                    name="maritalStatus"
                    onChange={handleChange}
                    required
                    className={tableInputClass}
                  >
                    <option value="">Select</option>
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                    <option value="Divorced">Divorced</option>
                  </select>
                </InfoRow>
              </div>
            </fieldset>

            {/* Business Type */}
            <fieldset disabled={isSubmitting}>
              <section>
                <h3 className={sectionTitle}>Type of business</h3>

                <div className="space-y-3 text-gray-800">
                  <label className="flex items-center gap-3">
                    <input
                      type="radio"
                      checked={formData.businessType === "individual"}
                      onClick={() =>
                        setFormData({ ...formData, businessType: "individual" })
                      }
                    />
                    Individual
                  </label>

                  <label className="flex items-center gap-3">
                    <input
                      type="radio"
                      checked={formData.businessType !== "individual"}
                      onClick={() =>
                        setFormData({ ...formData, businessType: "company" })
                      }
                    />
                    Company
                  </label>
                </div>

                <div className="mt-6 grid gap-5 md:grid-cols-2">
                  {formData.businessType === "individual" ? (
                    <>
                      <div>
                        <label className={labelClass}>
                          TFN / PAN / Tax ID *
                        </label>
                        <input
                          required
                          className={inputClass}
                          name="panId"
                          onChange={handleChange}
                        />
                      </div>

                      <div>
                        <label className={labelClass}>Date of birth *</label>
                        <input
                          type="date"
                          required
                          className={inputClass}
                          name="dob"
                          onChange={handleChange}
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      <div>
                        <label className={labelClass}>
                          ABN / Corporate ID *
                        </label>
                        <input
                          required
                          name="corporateId"
                          onChange={handleChange}
                          className={inputClass}
                        />
                      </div>

                      <div>
                        <label className={labelClass}>
                          TFN / PAN / Tax ID *
                        </label>
                        <input
                          required
                          name="panId"
                          onChange={handleChange}
                          className={inputClass}
                        />
                      </div>
                    </>
                  )}
                </div>
              </section>
            </fieldset>

            {/* Declaration */}
            <fieldset disabled={isSubmitting}>
              <section>
                <h3 className={sectionTitle}>Declaration</h3>

                <div className="space-y-4 rounded-sm border border-gray-200 bg-gray-50 p-4 text-sm leading-relaxed text-gray-700">
                  {DECLARATION.map((p) => (
                    <p key={p}>{p}</p>
                  ))}
                </div>
              </section>
            </fieldset>

            {/* Signature */}
            <fieldset disabled={isSubmitting}>
              <section>
                <h3 className={sectionTitle}>Sign</h3>

                <SignatureField
                  key={signatureKey}
                  onSignatureChange={setSignature}
                />

                <div className="mt-6 grid gap-5 md:grid-cols-2">
                  <div>
                    <label className={labelClass}>Name *</label>
                    <input
                      required
                      className={inputClass}
                      onChange={handleChange}
                      name="signatureName"
                    />
                  </div>

                  <div>
                    <label className={labelClass}>Date *</label>
                    <input
                      type="date"
                      onChange={handleChange}
                      name="signatureDate"
                      required
                      className={inputClass}
                    />
                  </div>
                </div>
              </section>
            </fieldset>

            {/* Submit */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full rounded-sm bg-orange-500 px-10 py-4 font-bold uppercase tracking-wide text-white shadow-lg transition-colors hover:bg-orange-600 disabled:pointer-events-none disabled:opacity-60 md:w-auto"
              >
                {isSubmitting ? "Submitting…" : "Submit form"}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
}
