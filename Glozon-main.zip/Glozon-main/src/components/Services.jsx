import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const SERVICES = [
  {
    title: "Managed Accounting & Financial Reporting",
    image: "/Managed-Accounting-Financial-Reporting-Vector-image1-scaled.jpg",
    description:
      "We provide detailed and scalable accounting solutions, ensuring your books are always accurate and compliant with international standards.",
    path: "/services/accounting-financial-reporting",
  },
  {
    title: "Taxation & Regulatory Advisory",
    image: "/Taxation-Regulatory-Advisory.jpg",
    description:
      "Our expert team navigates the complexities of tax regulations, providing proactive strategies to minimize your liabilities while ensuring compliance.",
    path: "/services/taxation-regulatory-advisory",
  },
  {
    title: "Audit Support & Assurance",
    image: "/Audit-Support-Assurance.jpg",
    description:
      "We offer seamless audit support, bridging the gap between your records and auditor expectations to ensure a smooth assurance process.",
    path: "/services/audit-support-assurance",
  },
  {
    title: "Corporate Secretarial & Entity Formation",
    image: "/Corporate-Secretarial-Entity-Formation.jpeg",
    description:
      "Let us handle the administrative and legal requirements of your business formation, allowing you to focus on your growth objectives.",
    path: "/services/corporate-secretarial",
  },
  {
    title: "Payroll Processing & Administration",
    image: "/Global-Payroll-Administration.jpg",
    description:
      "Our payroll services ensure that your workforce is compensated accurately and on time, maintaining compliance with local regulations.",
    path: "/services/payroll-processing",
  },
  {
    title: "Strategic Advisory & Corporate Finance",
    image: "/Strategic-Advisory-Corporate-Finance.jpg",
    description:
      "Unlock capital and drive expansion through our sophisticated financial modeling and strategic insights tailored for your business.",
    path: "/services/strategic-advisory",
  },
];

const Services = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5, ease: "easeOut" },
    },
  };

  return (
    <div className="bg-gray-50 py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="mx-auto mb-16 max-w-3xl text-center"
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="mb-6 text-3xl font-bold text-orange-500 md:text-4xl lg:text-5xl">
            Our Services
          </h2>

          <p className="text-lg text-gray-600">
            Discover our comprehensive suite of services designed to drive your
            business forward and ensure financial integrity.
          </p>
        </motion.div>

        <motion.div
          className="mx-auto grid max-w-7xl grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
        >
          {SERVICES.map((service, index) => (
            <motion.div
              key={service.path || index}
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className="group flex h-full flex-col overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-md transition-shadow duration-300 hover:shadow-2xl"
            >
              <div className="relative flex h-64 items-center justify-center overflow-hidden bg-blue-50/50 p-6">
                <div className="absolute inset-0 scale-0 rounded-full bg-blue-100/50 opacity-0 transition-transform duration-700 ease-in-out group-hover:scale-150 group-hover:opacity-100" />

                <motion.img
                  src={service.image}
                  alt={service.title}
                  className="relative z-10 h-48 w-48 rounded-full bg-white object-cover shadow-md"
                  whileHover={{ scale: 1.05, rotate: 2 }}
                  transition={{ duration: 0.3 }}
                />
              </div>

              <div className="relative z-10 flex flex-grow flex-col bg-white p-8 text-center">
                <h3 className="mb-4 flex h-14 items-center justify-center text-xl font-bold text-gray-800">
                  {service.title}
                </h3>

                <p className="mb-8 flex-grow text-gray-600">
                  {service.description}
                </p>

                <Link
                  to={service.path || "#"}
                  className="inline-block w-full rounded-md bg-pink-600 px-6 py-3 text-center font-medium text-white shadow-md transition-all duration-200 hover:scale-105 hover:bg-pink-700 active:scale-95"
                >
                  Learn More About Our Services
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
};

export default Services;