import React, { useState } from "react";
import { motion } from "framer-motion";
import API from "../API/Api";
const contactImg = "/contactus.jpg";

const COUNTRY_OPTIONS = ["Australia", "Nepal", "India", "Dubai"];

const inputClass =
  "w-full px-4 py-3 border border-gray-300 rounded-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors";

const labelClass = "block text-sm font-semibold text-gray-800 mb-1.5";

export default function Contact() {
  const [sending, setSending] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    country: "",
    phoneNumber: "",
    subject: "",
    message: "",
  });
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });

    console.log(formData);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post("/contact", formData);
      console.log(res);
      alert("Application Submitted Successfully!");
    } catch (e) {
      console.error("Error at : ", e);
    }

    setSending(true);

    e.target.reset();
    setSending(false);
  };

  return (
    <section className="py-16 bg-white" id="contact">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
        {/* Heading */}
        <div className="text-center mb-10">
          <motion.h2
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold text-orange-500 mb-6 uppercase tracking-wider"
          >
            Contact Us
          </motion.h2>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <img
              src={contactImg}
              alt="Contact Us Illustration"
              className="mx-auto w-[300px] h-[234px] object-contain"
            />
          </motion.div>
        </div>

        {/* Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-24 items-start mb-20">
          {/* Left side - contact info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="flex flex-col space-y-10 items-center text-center mt-8"
          >
            {/* Address */}
            <a
              href="https://maps.google.com"
              target="_blank"
              rel="noreferrer"
              className="block text-center group px-4 py-4 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <div className="w-16 h-16 rounded-full border-2 border-red-500 flex items-center justify-center mb-3 mx-auto">
                <svg
                  className="w-8 h-8 text-red-500"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
              </div>
              <h3 className="text-red-500 font-bold text-lg mb-2">Address</h3>
              <p className="text-gray-700 text-sm max-w-xs">
                Gaushala, Kathmandu, Nepal
              </p>
            </a>

            {/* Phone */}
            <a
              href="tel:+9779845971220"
              className="block text-center group px-4 py-4 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <div className="w-16 h-16 rounded-full border-2 border-green-500 flex items-center justify-center mb-3 mx-auto">
                <svg
                  className="w-8 h-8 text-green-500"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                  />
                </svg>
              </div>
              <h3 className="text-green-500 font-bold text-lg mb-2">Phone</h3>
              <p className="text-gray-700 text-sm">+977 9845971220</p>
            </a>

            {/* Email */}
            <a
              href="mailto:info@glozonfintax.com"
              className="block text-center group px-4 py-4 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <div className="w-16 h-16 rounded-full border-2 border-yellow-400 flex items-center justify-center mb-3 mx-auto">
                <svg
                  className="w-8 h-8 text-yellow-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                  />
                </svg>
              </div>
              <h3 className="text-yellow-500 font-bold text-lg mb-2">Email</h3>
              <p className="text-blue-500 text-sm">info@glozonfintax.com</p>
            </a>
          </motion.div>

          {/* Right side - form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="mt-8"
          >
            <h3 className="text-2xl font-bold text-blue-600 mb-2 uppercase text-center md:text-left">
              Get In Touch
            </h3>

            <p className="text-sm text-gray-600 mb-6 text-center md:text-left">
              Fill out the form below and we will get back to you soon.
            </p>

            <form onSubmit={handleSubmit} className="flex flex-col space-y-4">
              <div>
                <label className={labelClass}>Full Name *</label>
                <input
                  type="text"
                  required
                  className={inputClass}
                  onChange={handleChange}
                  name="name"
                />
              </div>

              <div>
                <label className={labelClass}>Email Address *</label>
                <input
                  type="email"
                  required
                  className={inputClass}
                  onChange={handleChange}
                  name="email"
                />
              </div>

              <div>
                <label className={labelClass}>Country *</label>
                <select
                  required
                  defaultValue=""
                  className={inputClass}
                  onChange={handleChange}
                  name="country"
                >
                  <option value="" disabled>
                    Select country
                  </option>
                  {COUNTRY_OPTIONS.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClass}>Mobile Number</label>
                <input
                  type="tel"
                  className={inputClass}
                  onChange={handleChange}
                  name="phoneNumber"
                />
              </div>

              <div>
                <label className={labelClass}>Subject</label>
                <input
                  type="text"
                  className={inputClass}
                  onChange={handleChange}
                  name="subject"
                />
              </div>

              <div>
                <label className={labelClass}>Message *</label>
                <textarea
                  required
                  rows={5}
                  className={`${inputClass} resize-y min-h-[120px]`}
                  onChange={handleChange}
                  name="message"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={sending}
                  className="px-8 py-3 bg-orange-500 hover:bg-orange-600 text-white font-bold uppercase tracking-wide rounded-sm shadow transition-colors disabled:opacity-60"
                >
                  {sending ? "Sending..." : "Send Message"}
                </button>
              </div>
            </form>
          </motion.div>
        </div>

        {/* Map */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="w-full h-[450px] border border-gray-200 overflow-hidden rounded-sm"
        >
          <iframe
            src="https://www.google.com/maps?q=Gaushala+Kathmandu&output=embed"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            title="Glozon FinTax Location Map"
          />
        </motion.div>
      </div>
    </section>
  );
}
