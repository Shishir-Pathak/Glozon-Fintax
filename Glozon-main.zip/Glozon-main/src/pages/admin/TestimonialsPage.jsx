import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  Plus,
  Pencil,
  Trash2,
  X,
  Upload,
} from "lucide-react";

const demoTestimonials = [
  {
    id: 1,
    name: "John Smith",
    position: "Business Owner",
    text: "Glozon Fintax helped us manage our taxes professionally and saved us a lot of time.",
    image: "/Logo.png",
  },
  {
    id: 2,
    name: "Sarah Johnson",
    position: "Entrepreneur",
    text: "Excellent accounting and advisory services. Highly recommended for startups.",
    image: "/Logo.png",
  },
];

export default function TestimonialsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [testimonials, setTestimonials] = useState(demoTestimonials);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const [formData, setFormData] = useState({
    name: "",
    position: "",
    text: "",
    image: "",
  });

  const filteredTestimonials = testimonials.filter(
    (t) =>
      t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.position.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const resetForm = () => {
    setFormData({
      name: "",
      position: "",
      text: "",
      image: "",
    });
    setEditing(null);
  };

  const openAddModal = () => {
    resetForm();
    setIsModalOpen(true);
  };

  const openEditModal = (testimonial) => {
    setEditing(testimonial.id);
    setFormData({
      name: testimonial.name,
      position: testimonial.position,
      text: testimonial.text,
      image: testimonial.image,
    });
    setIsModalOpen(true);
  };

  const handleSave = (e) => {
    e.preventDefault();

    if (editing) {
      setTestimonials((prev) =>
        prev.map((t) =>
          t.id === editing ? { ...t, ...formData } : t
        )
      );
    } else {
      setTestimonials((prev) => [
        ...prev,
        {
          id: Date.now(),
          ...formData,
          image: formData.image || "/Logo.png",
        },
      ]);
    }

    setIsModalOpen(false);
    resetForm();
  };

  const handleDelete = (id) => {
    setTestimonials((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-zinc-900">
            Testimonials
          </h1>
          <p className="text-zinc-500 mt-1">
            Manage client testimonials displayed on the website.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="inline-flex items-center gap-2 rounded-xl bg-[#18D1B2] px-4 py-3 text-sm font-semibold text-[#082032] hover:brightness-95 transition shadow-sm"
        >
          <Plus className="w-4 h-4" />
          Add Testimonial
        </button>
      </div>

      {/* Table Card */}
      <div className="rounded-3xl border border-zinc-200 bg-white shadow-sm overflow-hidden">
        {/* Search */}
        <div className="p-4 border-b border-zinc-100">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by name or position..."
              className="w-full rounded-xl border border-zinc-200 bg-zinc-50 pl-10 pr-4 py-3 text-sm outline-none focus:ring-4 focus:ring-[#102B55]/10 focus:border-[#102B55]"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white border-b border-zinc-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700 w-20">
                  SN
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Name
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Position
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Image
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700 min-w-[260px]">
                  Testimonial
                </th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-zinc-700 w-32">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-zinc-100">
              <AnimatePresence>
                {filteredTestimonials.length > 0 ? (
                  filteredTestimonials.map((testimonial, index) => (
                    <tr
                      key={testimonial.id}
                      className="hover:bg-zinc-50 transition"
                    >
                      <td className="px-6 py-5 text-sm font-medium text-zinc-500">
                        {index + 1}
                      </td>

                      <td className="px-6 py-5 font-semibold text-zinc-900 whitespace-nowrap">
                        {testimonial.name}
                      </td>

                      <td className="px-6 py-5">
                        <span className="inline-flex items-center rounded-full bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700 border border-indigo-100 whitespace-nowrap">
                          {testimonial.position}
                        </span>
                      </td>

                      <td className="px-6 py-5">
                        <img
                          src={testimonial.image}
                          alt={testimonial.name}
                          className="h-10 w-10 rounded-full object-cover border border-zinc-200"
                        />
                      </td>

                      <td className="px-6 py-5 text-zinc-600 text-sm max-w-[260px]">
                        <p className="truncate">{testimonial.text}</p>
                      </td>

                      <td className="px-6 py-5">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => openEditModal(testimonial)}
                            className="h-9 w-9 rounded-xl border border-zinc-200 flex items-center justify-center text-indigo-600 hover:bg-indigo-50 transition"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => handleDelete(testimonial.id)}
                            className="h-9 w-9 rounded-xl border border-zinc-200 flex items-center justify-center text-rose-600 hover:bg-rose-50 transition"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={6}
                      className="h-40 text-center text-zinc-500 align-middle"
                    >
                      No testimonials found.
                    </td>
                  </tr>
                )}
              </AnimatePresence>
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-zinc-100 px-6 py-4 bg-zinc-50/50">
          <p className="text-sm text-zinc-500">
            Showing {filteredTestimonials.length} testimonials
          </p>

          <div className="flex gap-2">
            <button className="rounded-lg border border-zinc-200 bg-white px-3 py-2 text-xs font-semibold text-zinc-500">
              Previous
            </button>
            <button className="rounded-lg border border-zinc-200 bg-white px-3 py-2 text-xs font-semibold text-zinc-500">
              Next
            </button>
          </div>
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="w-full max-w-2xl rounded-3xl bg-white shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between bg-[#5B4BFF] px-6 py-4 text-white">
                <h3 className="text-lg font-semibold">
                  {editing ? "Edit Testimonial" : "Add Testimonial"}
                </h3>

                <button
                  onClick={() => {
                    setIsModalOpen(false);
                    resetForm();
                  }}
                  className="rounded-lg p-2 hover:bg-white/10 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="p-6 space-y-5">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-600">
                    Name
                  </label>
                  <input
                    required
                    value={formData.name}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        name: e.target.value,
                      }))
                    }
                    className="w-full rounded-xl border border-zinc-200 px-4 py-3 outline-none focus:ring-4 focus:ring-[#102B55]/10 focus:border-[#102B55]"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-600">
                    Position
                  </label>
                  <input
                    required
                    value={formData.position}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        position: e.target.value,
                      }))
                    }
                    className="w-full rounded-xl border border-zinc-200 px-4 py-3 outline-none focus:ring-4 focus:ring-[#102B55]/10 focus:border-[#102B55]"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-600">
                    Image URL
                  </label>

                  <div className="flex items-center gap-3 rounded-xl border border-zinc-200 px-4 py-3">
                    <Upload className="w-4 h-4 text-zinc-500" />
                    <input
                      value={formData.image}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          image: e.target.value,
                        }))
                      }
                      placeholder="https://example.com/photo.jpg"
                      className="flex-1 outline-none text-sm"
                    />
                  </div>

                  {formData.image && (
                    <img
                      src={formData.image}
                      alt="Preview"
                      className="mt-3 h-20 w-20 rounded-xl object-cover border border-zinc-200"
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-600">
                    Testimonial
                  </label>
                  <textarea
                    required
                    rows={5}
                    value={formData.text}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        text: e.target.value,
                      }))
                    }
                    className="w-full rounded-xl border border-zinc-200 px-4 py-3 outline-none focus:ring-4 focus:ring-[#102B55]/10 focus:border-[#102B55]"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsModalOpen(false);
                      resetForm();
                    }}
                    className="rounded-xl bg-zinc-100 px-5 py-3 text-sm font-semibold text-zinc-700 hover:bg-zinc-200 transition"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    className="rounded-xl bg-[#18D1B2] px-5 py-3 text-sm font-semibold text-[#082032] hover:brightness-95 transition"
                  >
                    {editing ? "Update Testimonial" : "Save Testimonial"}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
