import {
  Plus,
  ClipboardList,
  BarChart3,
  ShieldCheck,
  Users,
  FileText,
  Clock3,
  AlertTriangle,
} from "lucide-react";


const activities = [
  {
    time: "09:42",
    client: "R. Whitfield",
    action: "Declaration signed",
    status: "Complete",
    color: "bg-green-100 text-green-700",
  },
  {
    time: "09:15",
    client: "Solent Trading Pty Ltd",
    action: "Onboarding submitted",
    status: "Pending",
    color: "bg-amber-100 text-amber-700",
  },
  {
    time: "08:57",
    client: "M. Okafor",
    action: "Tax ID verified",
    status: "Complete",
    color: "bg-green-100 text-green-700",
  },
  {
    time: "08:30",
    client: "Harrow & Vale Partners",
    action: "ATO correspondence received",
    status: "Action needed",
    color: "bg-indigo-100 text-indigo-700",
  },
  {
    time: "Yesterday",
    client: "J. Delacroix",
    action: "Lodgment overdue",
    status: "Overdue",
    color: "bg-red-100 text-red-700",
  },
];


export default function Dashboard() {


  return (

    <div className="space-y-6">


      {/* HERO */}

      <section className="relative overflow-hidden rounded-3xl bg-[#102B55] text-white p-8 md:p-10">


        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.08),transparent_35%)]" />



        <div className="relative flex flex-col md:flex-row md:items-start md:justify-between gap-8">


          <div className="max-w-2xl">


            <p className="text-xs tracking-[0.28em] uppercase text-white/60 font-semibold">

              Glozon Fintax & Advisory — Internal Portal

            </p>



            <h2 className="mt-4 text-4xl md:text-5xl font-semibold">

              Good morning, Admin.

            </h2>



            <p className="mt-4 text-white/70">

              Monday 3 August 2026

            </p>



            <div className="mt-8 flex flex-wrap gap-3">


              <ActionButton
                icon={Plus}
                label="New Client"
                primary
              />


              <ActionButton
                icon={ClipboardList}
                label="View Declarations"
              />


              <ActionButton
                icon={BarChart3}
                label="Generate Report"
              />


            </div>


          </div>





          <div className="flex justify-center md:justify-end">


            <div className="w-28 h-28 rounded-full border border-dashed border-[#D4A74A] flex items-center justify-center">


              <div className="text-center text-[#D4A74A]">


                <ShieldCheck className="w-6 h-6 mx-auto mb-2"/>


                <p className="text-[10px] font-semibold tracking-[0.22em] uppercase">

                  Verified
                  <br/>
                  System

                </p>


              </div>


            </div>


          </div>


        </div>


      </section>






      {/* STATS */}


      <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">


        <StatCard
          icon={Users}
          value="248"
          label="Active Clients"
          change="+12"
          iconBg="bg-emerald-100 text-emerald-600"
        />


        <StatCard
          icon={FileText}
          value="31"
          label="Declarations Signed"
          change="+6"
          iconBg="bg-indigo-100 text-indigo-600"
        />


        <StatCard
          icon={Clock3}
          value="9"
          label="Pending Review"
          change="-2"
          iconBg="bg-amber-100 text-amber-600"
        />


        <StatCard
          icon={AlertTriangle}
          value="4"
          label="Overdue Lodgments"
          change="+1"
          iconBg="bg-rose-100 text-rose-600"
        />


      </section>







      {/* ACTIVITY */}


      <section className="rounded-3xl border border-zinc-200 bg-white shadow-sm overflow-hidden">


        <div className="flex items-center justify-between px-6 py-5 border-b">


          <h3 className="text-2xl font-semibold">

            Recent activity

          </h3>


          <span className="text-xs uppercase text-zinc-400">

            Live Ledger

          </span>


        </div>





        <div className="divide-y">


          {
            activities.map((item)=>(


              <div
                key={item.time + item.client}
                className="grid grid-cols-[88px_1.3fr_1.5fr_auto] items-center gap-4 px-6 py-5 hover:bg-zinc-50 transition"
              >


                <div className="text-sm text-zinc-400">

                  {item.time}

                </div>



                <div className="font-semibold">

                  {item.client}

                </div>



                <div className="text-zinc-600">

                  {item.action}

                </div>



                <span
                  className={`rounded-full px-3 py-1 text-xs font-semibold ${item.color}`}
                >

                  {item.status}

                </span>



              </div>


            ))
          }


        </div>


      </section>



    </div>

  );

}







function ActionButton({icon:Icon,label,primary}){


  return (

    <button

      className={`

      inline-flex
      items-center
      gap-2
      rounded-xl
      px-5
      py-3
      text-sm
      font-semibold
      transition


      ${
        primary
        ?
        "bg-[#18D1B2] text-[#082032] hover:brightness-95"
        :
        "border border-white/15 bg-white/5 text-white hover:bg-white/10"
      }

      `}

    >

      <Icon className="w-4 h-4"/>

      {label}

    </button>

  );

}







function StatCard({icon:Icon,value,label,change,iconBg}){


  return (

    <div className="rounded-3xl border border-zinc-200 bg-white p-6 shadow-sm">


      <div className="flex justify-between">


        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${iconBg}`}>

          <Icon className="w-6 h-6"/>

        </div>



        <span className="text-sm text-zinc-400">

          {change}

        </span>


      </div>




      <div className="mt-6">


        <div className="text-4xl font-bold">

          {value}

        </div>


        <div className="mt-2 text-xs uppercase text-zinc-400">

          {label}

        </div>


      </div>


    </div>

  );

}