import { useState } from "react";
import { motion } from "framer-motion";
import { Search, Plus, Layers3 } from "lucide-react";

export default function ServicesPage() {
  const [search, setSearch] = useState("");

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold text-[#0F172A]">Services</h2>
          <p className="text-zinc-500 mt-2 text-lg">
            Manage service categories and their detail items for the public site.
          </p>
        </div>

        <div className="flex gap-3">
          <button className="inline-flex items-center gap-2 rounded-xl bg-[#5B4BFF] px-4 py-3 text-sm font-semibold text-white hover:brightness-95 transition shadow-sm">
            <Layers3 className="w-4 h-4" />
            Add Service Category
          </button>

          <button className="inline-flex items-center gap-2 rounded-xl bg-[#18D1B2] px-4 py-3 text-sm font-semibold text-[#082032] hover:brightness-95 transition shadow-sm">
            <Plus className="w-4 h-4" />
            Add Service Item
          </button>
        </div>
      </div>

      {/* Table Card */}
      <div className="rounded-3xl border border-zinc-200 bg-white shadow-sm overflow-hidden">
        {/* Search row */}
        <div className="p-4 border-b border-zinc-100">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />

            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by category or item title..."
              className="w-full rounded-xl border border-zinc-200 bg-zinc-50 pl-10 pr-4 py-3 text-sm outline-none focus:ring-4 focus:ring-[#102B55]/10 focus:border-[#102B55]"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white border-b border-zinc-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700 w-20">
                  SN
                </th>

                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Service Category
                </th>

                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Item Title
                </th>

                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Title Color
                </th>

                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Icon Color
                </th>

                <th className="px-6 py-4 text-right text-sm font-semibold text-zinc-700 w-32">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody>
              <tr>
                <td
                  colSpan={6}
                  className="h-64 text-center text-zinc-500 align-middle"
                >
                  No service items found. Add a category first, then add items.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}