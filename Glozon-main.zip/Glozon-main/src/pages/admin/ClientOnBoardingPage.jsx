import React, { useState, useEffect } from "react";
import {
  Eye,
  Trash2,
  Search,
  FileText,
  CheckCircle2,
  Download,
  ShieldCheck,
  XCircle,
  Loader2,
  X,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import * as XLSX from "xlsx";
import API from "../../API/Api";

const ClientOnboardingPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [businessFilter, setBusinessFilter] = useState("All");
  const [selectedForm, setSelectedForm] = useState(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [forms, setForms] = useState([]);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deletingId, setDeletingId] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    fetchForms();
  }, []);

  const fetchForms = async () => {
    setIsLoading(true);
    try {
      const res = await API.get("/onboarding", {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      });
      setForms(res.data);
    } catch (error) {
      console.error("Failed to fetch forms:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteClick = (formId) => {
    setDeletingId(formId);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = async () => {
    if (!deletingId) return;
    setIsDeleting(true);
    try {
      await API.delete("/onboarding/" + deletingId, {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      });
      setForms((prev) => prev.filter((f) => f.id !== deletingId));
    } catch (error) {
      console.error("Failed to delete form:", error);
    } finally {
      setIsDeleting(false);
      setIsDeleteModalOpen(false);
      setDeletingId(null);
    }
  };

  const handleViewDetails = (form) => {
    setSelectedForm(form);
    setIsViewModalOpen(true);
  };

  const handleViewPDF = (e, form) => {
    e.stopPropagation();

    const pdfUrl = form.oneDriveUrl || form.pdfUrl;

    if (!pdfUrl || pdfUrl === "#") {
      alert("PDF file not available.");
      return;
    }

    window.open(pdfUrl, "_blank");
  };

  const filteredForms = forms
    .filter((form) => {
      if (businessFilter === "All") return true;
      return (
        (form.businessType || "").toLowerCase() === businessFilter.toLowerCase()
      );
    })
    .filter(
      (form) =>
        (form.firstName || "")
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        (form.lastName || "")
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        (form.email || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
        (form.taxId || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
        (form.signerName || "")
          .toLowerCase()
          .includes(searchTerm.toLowerCase()),
    );

  const exportToExcel = () => {
    const excelData = filteredForms.map((form, index) => ({
      SN: index + 1,
      "Business Type": form.businessType,
      "First Name": form.firstName,
      "Last Name": form.lastName,
      Email: form.email,
      Phone: form.contactNo,
      Country: form.country,
      "Tax ID": form.taxId,
      "Authority Accepted": form.authorityAccepted ? "Yes" : "No",
      "Signer Name": form.signerName,
      "Sign Date": form.signDate,
      "Created At": form.createdAt
        ? new Date(form.createdAt).toLocaleString()
        : "",
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Client Submissions");
    XLSX.writeFile(workbook, "Client_Submissions.xlsx");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-[#0F172A]">
            Client Declaration Forms
          </h1>
          <p className="text-zinc-500 mt-1">
            Detailed management of onboarding submissions and digital
            signatures.
          </p>
        </div>

        <button
          onClick={exportToExcel}
          className="inline-flex items-center gap-2 rounded-xl bg-green-600 hover:bg-green-700 text-white px-4 py-3 text-sm font-semibold transition shadow-sm"
        >
          <Download className="w-4 h-4" />
          Export Excel
        </button>
      </div>

      {/* Table Card */}
      <div className="rounded-3xl border border-zinc-200 bg-white shadow-sm overflow-hidden">
        {/* Search + Filter row */}
        <div className="p-4 border-b border-zinc-100 flex flex-col md:flex-row items-stretch md:items-center gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by name, email, TFN or signer..."
              className="w-full rounded-xl border border-zinc-200 bg-zinc-50 pl-9 pr-4 py-3 text-sm outline-none focus:ring-4 focus:ring-[#102B55]/10 focus:border-[#102B55] transition"
            />
          </div>

          <select
            value={businessFilter}
            onChange={(e) => setBusinessFilter(e.target.value)}
            className="h-11 rounded-xl border border-zinc-200 bg-white px-3 text-sm outline-none focus:ring-4 focus:ring-[#102B55]/10 focus:border-[#102B55] transition"
          >
            <option value="All">All Submissions</option>
            <option value="Individual">Individual</option>
            <option value="Entity">Entity</option>
          </select>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-zinc-50 border-b border-zinc-200">
              <tr>
                <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-widest text-zinc-500 w-16">
                  SN
                </th>
                <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                  Business Type
                </th>
                <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                  Name
                </th>
                <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                  Tax ID/TFN
                </th>
                <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                  Signature
                </th>
                <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                  Confirmed
                </th>
                <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                  Signer Name
                </th>
                <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                  Sign Date
                </th>
                <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                  PDF
                </th>
                <th className="px-6 py-4 text-right text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                  Action
                </th>
              </tr>
            </thead>

            <tbody>
              <AnimatePresence>
                {isLoading ? (
                  <tr>
                    <td colSpan={10} className="h-40 text-center">
                      <div className="flex items-center justify-center gap-2 text-zinc-500">
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Loading submissions...
                      </div>
                    </td>
                  </tr>
                ) : filteredForms.length > 0 ? (
                  filteredForms.map((form, index) => (
                    <tr
                      key={form.id || index}
                      className="group border-b border-zinc-100 hover:bg-zinc-50/70 transition-colors"
                    >
                      <td className="px-6 py-4 font-medium text-zinc-500">
                        {index + 1}
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                            form.businessType === "Individual" ||
                            form.businessType === "individual"
                              ? "bg-sky-100 text-sky-700"
                              : "bg-amber-100 text-amber-700"
                          }`}
                        >
                          {form.businessType}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex flex-col">
                          <span className="font-bold text-zinc-900">
                            {form.firstName} {form.lastName}
                          </span>
                          <span className="text-[11px] text-zinc-500">
                            {form.email}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-mono text-[11px] font-bold text-zinc-600">
                        {form.taxId || form.panId}
                      </td>
                      <td className="px-6 py-4">
                        <div className="w-12 h-6 bg-zinc-50 border border-zinc-200 rounded p-0.5 overflow-hidden flex items-center justify-center hover:scale-500 transition-all duration-200 ease-in">
                          <img
                            src={form.signature || form.signatureUrl}
                            alt="Sign"
                            className="max-w-full max-h-full object-contain grayscale"
                          />
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {form.authorityAccepted || form?.checked ? (
                          <div className="flex items-center gap-1.5 text-emerald-600 font-bold text-[10px] uppercase">
                            <ShieldCheck className="w-3.5 h-3.5" />
                            Yes
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 text-rose-600 font-bold text-[10px] uppercase">
                            <XCircle className="w-3.5 h-3.5" />
                            No
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 font-bold text-zinc-700 text-[11px]">
                        {form.signerName || form.signatureName}
                      </td>
                      <td className="px-6 py-4 text-zinc-500 text-[11px] font-bold">
                        {form.signDate ||
                          (form.createdAt
                            ? new Date(form.createdAt).toLocaleDateString()
                            : "")}
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={(e) => handleViewPDF(e, form)}
                          className="h-8 w-8 flex items-center justify-center text-[#00c69d] hover:text-[#00b08c] hover:bg-[#00c69d]/10 rounded-full transition"
                        >
                          <FileText className="w-4 h-4" />
                        </button>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleViewDetails(form)}
                            className="bg-[#00c69d] hover:bg-[#00b08c] text-white h-8 px-3 text-[10px] font-black rounded-md shadow-sm transition-all uppercase tracking-wider inline-flex items-center"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteClick(form.id)}
                            className="bg-[#ff5b5b] hover:bg-[#ee4a4a] cursor-pointer text-white h-8 px-3 text-[10px] font-black rounded-md shadow-sm transition-all uppercase tracking-wider inline-flex items-center"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={10}
                      className="h-40 text-center text-zinc-500 font-medium"
                    >
                      No matching records found.
                    </td>
                  </tr>
                )}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </div>

      {/* View Form Modal */}
      <AnimatePresence>
        {isViewModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/50"
              onClick={() => setIsViewModalOpen(false)}
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 10 }}
              className="relative bg-white w-full max-w-[750px] max-h-[90vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col"
            >
              <div className="overflow-y-auto">
                <div className="p-8 bg-white space-y-10">
                  {/* Your Information */}
                  <section className="space-y-6">
                    <h3 className="font-bold text-blue-500 text-lg border-b border-zinc-100 pb-2">
                      OnBoarding Information
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                      <InfoField
                        label="First name *"
                        value={selectedForm?.firstName}
                      />
                      <InfoField
                        label="Last name *"
                        value={selectedForm?.lastName}
                      />
                      <InfoField label="Email *" value={selectedForm?.email} />
                      <InfoField
                        label="Contact no. *"
                        value={selectedForm?.phoneNumber}
                      />
                      <div className="md:col-span-2">
                        <InfoField
                          label="Country *"
                          value={selectedForm?.country}
                        />
                      </div>
                    </div>
                  </section>

                  <section className="space-y-6">
                    <h3 className="font-bold text-blue-500 text-lg border-b border-zinc-100 pb-2">
                      Type of business
                    </h3>
                    <div className="space-y-4">
                      <div className="flex flex-col gap-3">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-4 h-4 rounded-full border-2 ${
                              selectedForm?.businessType === "individual"
                                ? "border-blue-500 bg-blue-500 ring-4 ring-blue-50 p-0.5"
                                : "border-zinc-300"
                            }`}
                          >
                            {selectedForm?.businessType === "individual" && (
                              <div className="w-full h-full bg-white rounded-full" />
                            )}
                          </div>
                          <span className="text-sm font-bold text-zinc-700 tracking-tight">
                            Option 1: Individual
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-4 h-4 rounded-full border-2 ${
                              selectedForm?.businessType === "company"
                                ? "border-blue-500 bg-blue-500 ring-4 ring-blue-50 p-0.5"
                                : "border-zinc-300"
                            }`}
                          >
                            {selectedForm?.businessType === "company" && (
                              <div className="w-full h-full bg-white rounded-full" />
                            )}
                          </div>
                          <span className="text-sm font-bold text-zinc-700 tracking-tight">
                            Option 2: Entity (Company, Trust, Partnership etc.)
                          </span>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6 pt-4">
                        <InfoField
                          label="TFN/PAN/Tax ID Number *"
                          value={selectedForm?.panId}
                        />
                        <InfoField
                          label={
                            selectedForm?.dob
                              ? "Date of birth *"
                              : "Corporate Id *"
                          }
                          value={selectedForm?.dob || selectedForm?.corporateId}
                        />
                      </div>
                    </div>
                  </section>

                  <section className="space-y-6">
                    <h3 className="font-bold text-blue-500 text-lg border-b border-zinc-100 pb-2">
                      Sign
                    </h3>
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest pl-1">
                          Signature box (mouse or touch)
                        </p>
                        <div className="h-40 bg-zinc-100/30 border-2 border-dashed border-zinc-200 rounded-xl flex items-center justify-center p-8">
                          <img
                            src={
                              selectedForm?.signature ||
                              selectedForm?.signatureUrl
                            }
                            alt="Client Signature"
                            className="max-h-full max-w-full object-contain grayscale brightness-90 px-4"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6 pt-2">
                        <InfoField
                          label="Name *"
                          value={selectedForm?.signatureName}
                        />
                        <InfoField
                          label="Date *"
                          value={selectedForm?.signatureDate}
                        />
                      </div>
                    </div>
                  </section>

                  {!selectedForm?.checked && (
                    <div className="flex items-center justify-end pt-10 border-t border-zinc-100 gap-4">
                      <button
                        onClick={async () => {
                          try {
                            await API.put(
                              "/onboarding/" + selectedForm.id,
                              {},
                              {
                                headers: {
                                  Authorization:
                                    "Bearer " + localStorage.getItem("token"),
                                },
                              },
                            );
                            setForms((prev) =>
                              prev.map((item) =>
                                item.id === selectedForm.id
                                  ? { ...item, checked: true }
                                  : { ...item },
                              ),
                            );
                            setIsViewModalOpen(false);
                          } catch (e) {
                            console.error(e);
                          }
                        }}
                        className="border border-green-200 text-green-500 hover:bg-green-50 font-bold rounded-xl h-12 px-8 text-xs uppercase tracking-widest transition"
                      >
                        Checked
                      </button>
                      <button
                        onClick={() => setIsViewModalOpen(false)}
                        className="bg-zinc-900 hover:bg-black text-white px-12 h-12 font-black rounded-xl shadow-xl transition-all uppercase tracking-widest text-xs"
                      >
                        Close Record
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete confirmation Modal */}
      <AnimatePresence>
        {isDeleteModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/50"
              onClick={() => setIsDeleteModalOpen(false)}
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 10 }}
              className="relative bg-white w-full max-w-[450px] rounded-xl shadow-2xl overflow-hidden"
            >
              <div className="bg-rose-600 px-6 py-4 flex items-center justify-between">
                <h3 className="text-white text-lg font-semibold tracking-wide">
                  Confirm Deletion
                </h3>
              </div>

              <div className="p-6 bg-white border-[10px] border-rose-50/50 space-y-4">
                <div className="flex items-center gap-3 text-rose-600">
                  <Trash2 className="w-6 h-6 shrink-0" />
                  <h3 className="font-semibold text-lg">
                    Are you sure want to delete?
                  </h3>
                </div>
                <p className="text-zinc-600 text-sm leading-relaxed">
                  This action is permanent and cannot be undone. This submission
                  will be permanently deleted from the database.
                </p>

                <div className="flex items-center justify-end gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setIsDeleteModalOpen(false)}
                    className="bg-zinc-100 hover:bg-zinc-200 text-zinc-700 px-6 h-10 font-medium rounded-md shadow-sm transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={isDeleting}
                    onClick={confirmDelete}
                    className="bg-rose-600 hover:bg-rose-700 text-white px-6 h-10 font-medium rounded-md shadow-sm flex items-center gap-2 transition disabled:opacity-60"
                  >
                    {isDeleting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                    Delete
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// Custom Information Field to match the form input style
const InfoField = ({ label, value }) => (
  <div className="space-y-2 group">
    <label className="text-[10px] font-black text-zinc-400 group-hover:text-blue-400 transition-colors uppercase tracking-widest pl-1">
      {label}
    </label>
    <div className="w-full px-4 py-3.5 bg-zinc-50/80 border border-zinc-200 rounded-xl font-bold text-zinc-900 text-sm shadow-sm group-hover:border-blue-200 transition-all">
      {value || "N/A"}
    </div>
  </div>
);

export default ClientOnboardingPage;
