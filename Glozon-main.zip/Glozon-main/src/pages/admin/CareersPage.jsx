import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Eye,
  Trash2,
  Search,
  Mail,
  Phone,
  Calendar,
  Globe,
  MessageSquare,
  FileText,
  Download,
  X,
  GraduationCap,
  Briefcase,
  CheckCircle,
  XCircle,
  RefreshCcw,
} from "lucide-react";
import API from "../../API/Api";

export default function CareersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedApplication, setSelectedApplication] = useState(null);
  console.log(selectedApplication, "Selected");
  const [demoApplications, setDemo] = useState([
    {
      id: 1,
      fullName: "John Smith",
      email: "john@example.com",
      mobile: "+61 412 345 678",
      country: "Australia",
      position: "Tax Consultant",
      experience: "5 Years",
      coverLetter:
        "I would like to apply for the Tax Consultant position. I have experience in taxation and compliance services.",
      appliedDate: "2026-08-03",
      status: "Pending",
    },
    {
      id: 2,
      fullName: "Sarah Johnson",
      email: "sarah@example.com",
      mobile: "+977 9812345678",
      country: "Nepal",
      position: "Accountant",
      experience: "3 Years",
      coverLetter:
        "I am interested in joining your accounting team and contributing my bookkeeping and financial reporting skills.",
      appliedDate: "2026-08-02",
      status: "Reviewed",
    },
  ]);

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await API.get("/careers", {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        });
        setDemo(res.data);
      } catch (e) {
        console.error(e);
      }
    };
    fetch();
  }, []);

  const filteredApplications = demoApplications.filter(
    (app) =>
      app.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.position.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const getStatusBadge = (status) => {
    switch (status) {
      case "pending":
        return (
          <span className="inline-flex items-center rounded-full bg-amber-50 px-3 py-1 text-xs font-bold text-amber-700 border border-amber-200 uppercase">
            Pending
          </span>
        );
      case "approved":
        return (
          <span className="inline-flex items-center rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700 border border-blue-200 uppercase">
            Reviewed
          </span>
        );
      case "shortlisted":
        return (
          <span className="inline-flex items-center rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 border border-emerald-200 uppercase">
            Shortlisted
          </span>
        );
      case "rejected":
        return (
          <span className="inline-flex items-center rounded-full bg-rose-50 px-3 py-1 text-xs font-bold text-rose-700 border border-rose-200 uppercase">
            Rejected
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-[#0F172A]">
          Career Applications
        </h1>
        <p className="text-zinc-500 mt-1">
          Review applicant details and manage recruitment statuses.
        </p>
      </div>

      <div className="rounded-3xl border border-zinc-200 bg-white shadow-sm overflow-hidden">
        <div className="p-4 border-b border-zinc-100">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by name, email or position..."
              className="w-full rounded-xl border border-zinc-200 bg-zinc-50 pl-10 pr-4 py-3 text-sm outline-none focus:ring-4 focus:ring-[#102B55]/10 focus:border-[#102B55]"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-zinc-50 border-b border-zinc-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700 w-16">
                  SN
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Applicant
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Position
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Country
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Applied Date
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-zinc-700">
                  Status
                </th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-zinc-700 w-36">
                  Action
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-zinc-100">
              {filteredApplications.map((app, index) => (
                <tr key={app.id} className="hover:bg-zinc-50 transition">
                  <td className="px-6 py-5 text-sm font-medium text-zinc-500">
                    {index + 1}
                  </td>

                  <td className="px-6 py-5">
                    <div className="flex flex-col">
                      <span className="font-semibold text-zinc-900">
                        {app.fullName}
                      </span>
                      <span className="text-sm text-zinc-500">{app.email}</span>
                    </div>
                  </td>

                  <td className="px-6 py-5">
                    <span className="inline-flex items-center rounded-full bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700 border border-indigo-100">
                      {app.position}
                    </span>
                  </td>

                  <td className="px-6 py-5 text-zinc-600">{app.country}</td>

                  <td className="px-6 py-5 text-zinc-500 text-sm">
                    {new Date(
                      app.appliedDate || app.createdAt,
                    ).toLocaleDateString()}
                  </td>

                  <td className="px-6 py-5">
                    {getStatusBadge(app.status || app.approveStatus)}
                  </td>

                  <td className="px-6 py-5">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setSelectedApplication(app)}
                        className="inline-flex items-center gap-2 rounded-xl bg-[#18D1B2] px-3 py-2 text-sm font-semibold text-[#082032] hover:brightness-95 transition"
                      >
                        <Eye className="w-4 h-4" />
                        View
                      </button>

                      <button className="inline-flex items-center gap-2 rounded-xl bg-[#FF5B5B] px-3 py-2 text-sm font-semibold text-white hover:brightness-95 transition">
                        <Trash2 className="w-4 h-4" />
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedApplication && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
          onClick={() => setSelectedApplication(null)}
        >
          <div
            className="w-full max-w-3xl rounded-3xl bg-white shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between bg-[#5B4BFF] px-6 py-4 text-white">
              <div className="flex items-center gap-3">
                <Briefcase className="w-5 h-5" />
                <h3 className="text-lg font-semibold">Applicant Profile</h3>
              </div>

              <button
                onClick={() => setSelectedApplication(null)}
                className="rounded-lg p-2 hover:bg-white/10 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div>
                  <h4 className="text-2xl font-bold text-zinc-900">
                    {selectedApplication.fullName}
                  </h4>
                  <p className="text-indigo-600 font-semibold mt-1">
                    {selectedApplication.position}
                  </p>
                </div>

                {getStatusBadge(
                  selectedApplication.status ||
                    selectedApplication.approveStatus,
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <Info
                  label="Email"
                  value={selectedApplication.email}
                  icon={Mail}
                />
                <Info
                  label="Mobile"
                  value={
                    selectedApplication.mobile ||
                    selectedApplication.phoneNumber
                  }
                  icon={Phone}
                />
                <Info
                  label="Country"
                  value={selectedApplication.country}
                  icon={Globe}
                />
                <Info
                  label="Experience"
                  value={selectedApplication.experience}
                  icon={GraduationCap}
                />
                <Info
                  label="Applied Date"
                  value={new Date(
                    selectedApplication.appliedDate ||
                      selectedApplication.updatedAt,
                  ).toLocaleDateString()}
                  icon={Calendar}
                />
              </div>

              <div className="rounded-2xl border border-zinc-200 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <MessageSquare className="w-5 h-5 text-indigo-600" />
                  <h5 className="font-semibold text-zinc-900">Cover Letter</h5>
                </div>

                <p className="text-zinc-700 leading-relaxed whitespace-pre-wrap">
                  {selectedApplication.coverLetter}
                </p>
              </div>

              <div className="flex items-center justify-between flex-wrap gap-3 pt-4 border-t border-zinc-100">
                <div className="flex gap-3">
                  <button
                    className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 transition"
                    onClick={async () => {
                      await API.put(
                        "/careers/" + selectedApplication.id,
                        {
                          status: "shortlisted",
                        },
                        {
                          headers: {
                            Authorization:
                              "Bearer " + localStorage.getItem("token"),
                          },
                        },
                      );
                      setDemo((prev) =>
                        prev.map((item) =>
                          item.id === selectedApplication.id
                            ? {
                                ...item,

                                approveStatus: "shortlisted",
                              }
                            : item,
                        ),
                      );

                      setSelectedApplication((prev) => ({
                        ...prev,

                        approveStatus: "shortlisted",
                      }));
                    }}
                  >
                    <CheckCircle className="w-4 h-4" />
                    Shortlist
                  </button>

                  <button
                    className="inline-flex items-center gap-2 rounded-xl border border-rose-200 px-4 py-2 text-sm font-semibold text-rose-600 hover:bg-rose-50 transition"
                    onClick={async () => {
                      console.log(selectedApplication);
                      await API.put(
                        "/careers/" + selectedApplication.id,
                        {
                          status: "rejected",
                        },
                        {
                          headers: {
                            Authorization:
                              "Bearer " + localStorage.getItem("token"),
                          },
                        },
                      );
                      setDemo((prev) =>
                        prev.map((item) =>
                          item.id === selectedApplication.id
                            ? {
                                ...item,
                                status: "rejected",
                                approveStatus: "rejected",
                              }
                            : item,
                        ),
                      );

                      setSelectedApplication((prev) => ({
                        ...prev,
                        status: "rejected",
                        approveStatus: "rejected",
                      }));
                    }}
                  >
                    <XCircle className="w-4 h-4" />
                    Reject
                  </button>
                </div>

                <button
                  onClick={() => setSelectedApplication(null)}
                  className="rounded-xl bg-zinc-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-zinc-800 transition"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}

function Info({ label, value, icon: Icon }) {
  return (
    <div className="rounded-2xl border border-zinc-200 p-4">
      <div className="flex items-center gap-2 text-sm text-zinc-500 font-medium">
        <Icon className="w-4 h-4" />
        {label}
      </div>
      <div className="mt-2 text-zinc-900 font-semibold break-words">
        {value}
      </div>
    </div>
  );
}
