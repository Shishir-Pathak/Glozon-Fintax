import React, { useEffect, useState } from "react";
import {
  ArrowUpRight,
  Clock3,
  Edit3,
  MapPin,
  Phone,
  Loader2,
} from "lucide-react";


export default function SettingsPage() {

  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);


  useEffect(() => {

    const demoSettings = {

      companyName: "Glozon FinTax",

      tagline: "Finance, Tax & Advisory Solutions",

      logo: "",

      primaryEmail: "info@glozonfintax.com",

      secondaryEmail: "support@glozonfintax.com",

      primaryPhone: "+977 9800000000",

      secondaryPhone: "+977 9811111111",

      whatsapp: "+977 9800000000",

      address: "Kathmandu, Nepal",

      website: "https://glozonfintax.com",


      businessHours: [

        {
          day: "Sunday",
          isOpen: true,
          openTime: "10:00 AM",
          closeTime: "5:00 PM",
        },

        {
          day: "Monday",
          isOpen: true,
          openTime: "10:00 AM",
          closeTime: "5:00 PM",
        },

        {
          day: "Tuesday",
          isOpen: true,
          openTime: "10:00 AM",
          closeTime: "5:00 PM",
        },

        {
          day: "Wednesday",
          isOpen: true,
          openTime: "10:00 AM",
          closeTime: "5:00 PM",
        },

        {
          day: "Thursday",
          isOpen: true,
          openTime: "10:00 AM",
          closeTime: "5:00 PM",
        },

        {
          day: "Friday",
          isOpen: false,
        },

        {
          day: "Saturday",
          isOpen: false,
        },

      ],

    };


    setTimeout(() => {

      setSettings(demoSettings);

      setLoading(false);

    }, 500);


  }, []);



  if (loading) {

    return (

      <div className="h-screen flex items-center justify-center">

        <Loader2 className="animate-spin text-indigo-600" />

      </div>

    );

  }



  const contactItems = [

    {
      label: "Primary Email",
      value: settings.primaryEmail,
    },

    {
      label: "Secondary Email",
      value: settings.secondaryEmail,
    },

    {
      label: "Primary Phone",
      value: settings.primaryPhone,
    },

    {
      label: "Secondary Phone",
      value: settings.secondaryPhone,
    },

    {
      label: "WhatsApp",
      value: settings.whatsapp,
    },

  ];



  const openDays = settings.businessHours.filter(
    item => item.isOpen
  );



  return (

    <div className="min-h-screen bg-slate-100 p-6">

      <div className="max-w-7xl mx-auto space-y-6">


        {/* HEADER */}

        <div className="bg-white rounded-3xl p-6 shadow flex justify-between items-center">

          <div>

            <p className="text-indigo-600 text-sm uppercase">
              Admin Settings
            </p>

            <h1 className="text-3xl font-bold text-slate-900">
              Company Information
            </h1>

            <p className="text-slate-500 mt-2">
              Manage your company details
            </p>

          </div>


          <button className="bg-slate-900 text-white px-5 py-3 rounded-full flex items-center gap-2">

            <Edit3 size={18}/>

            Edit Information

          </button>


        </div>




        <div className="grid lg:grid-cols-[350px_1fr] gap-6">


          {/* LEFT SIDE */}

          <div className="space-y-6">


            <div className="bg-white rounded-3xl shadow overflow-hidden">


              <div className="h-24 bg-gradient-to-r from-indigo-500 to-cyan-400" />


              <div className="p-6 text-center">


                <img
                  src={
                    settings.logo ||
                    "https://via.placeholder.com/150"
                  }
                  alt="logo"
                  className="w-28 h-28 rounded-2xl mx-auto object-cover -mt-14 border-4 border-white"
                />


                <h2 className="text-2xl font-bold mt-4">
                  {settings.companyName}
                </h2>


                <p className="text-slate-500">
                  {settings.tagline}
                </p>


              </div>


            </div>




            <div className="bg-white rounded-3xl shadow p-6">


              <div className="flex items-center gap-3 mb-5">

                <Phone className="text-indigo-600"/>

                <h2 className="font-bold text-lg">
                  Contact Information
                </h2>

              </div>



              {
                contactItems.map(item => (

                  <div
                    key={item.label}
                    className="border-b py-3"
                  >

                    <p className="text-xs uppercase text-slate-500">
                      {item.label}
                    </p>


                    <p className="font-medium text-sm">
                      {item.value}
                    </p>


                  </div>

                ))
              }


            </div>


          </div>





          {/* RIGHT SIDE */}


          <div className="space-y-6">


            <div className="grid md:grid-cols-2 gap-6">


              {/* ADDRESS */}

              <div className="bg-white rounded-3xl shadow p-6">


                <div className="flex gap-3 mb-5 items-center">

                  <MapPin className="text-cyan-600"/>

                  <h2 className="font-bold text-lg">
                    Address
                  </h2>

                </div>


                <p>
                  {settings.address}
                </p>



                <a
                  href={settings.website}
                  target="_blank"
                  rel="noreferrer"
                  className="text-indigo-600 flex gap-2 mt-4 text-sm"
                >

                  Website

                  <ArrowUpRight size={15}/>

                </a>


              </div>






              {/* BUSINESS HOURS */}

              <div className="bg-white rounded-3xl shadow p-6">


                <div className="flex gap-3 mb-5 items-center">

                  <Clock3 className="text-orange-500"/>

                  <h2 className="font-bold text-lg">
                    Business Hours
                  </h2>

                </div>



                {
                  settings.businessHours.map(item => (

                    <div
                      key={item.day}
                      className="flex justify-between border-b py-3"
                    >

                      <span>
                        {item.day}
                      </span>


                      <span>

                        {
                          item.isOpen
                          ?
                          `${item.openTime} - ${item.closeTime}`
                          :
                          "Closed"
                        }

                      </span>


                    </div>

                  ))
                }


              </div>


            </div>






            {/* CARDS */}

            <div className="grid md:grid-cols-3 gap-5">


              <div className="bg-white rounded-3xl shadow p-5">

                <p>Status</p>

                <h2 className="text-xl font-bold">
                  Active
                </h2>

              </div>




              <div className="bg-white rounded-3xl shadow p-5">

                <p>Coverage</p>

                <h2 className="text-xl font-bold">

                  {
                    openDays.length
                    ?
                    `${openDays[0].day} - ${openDays[openDays.length-1].day}`
                    :
                    "Not set"
                  }

                </h2>

              </div>




              <div className="bg-white rounded-3xl shadow p-5">

                <p>Support</p>

                <h2 className="text-xl font-bold">
                  Fast Response
                </h2>

              </div>


            </div>


          </div>


        </div>


      </div>


    </div>

  );

}